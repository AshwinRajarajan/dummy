This is the directory where various libraries and essential object files (crt0.o, end.o) are kept

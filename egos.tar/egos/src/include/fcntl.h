#ifndef EGOS_FCNTL_H
#define EGOS_FCNTL_H

#define SEEK_SET	1
#define SEEK_CUR	2
#define SEEK_END	3

#endif // EGOS_FCNTL_H

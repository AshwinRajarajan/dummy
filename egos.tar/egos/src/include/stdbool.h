#ifndef EGOS_STDBOOL_H
#define EGOS_STDBOOL_H

typedef enum { false, true } bool;

#endif // EGOS_STDBOOL_H

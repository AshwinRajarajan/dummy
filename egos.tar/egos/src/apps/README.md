This directory contain the various user space application developed
for the grass operating system.

#include <stdio.h>

int main(int argc, char **argv){
	fflushsync(NULL);
	return 0;
}

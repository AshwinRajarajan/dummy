This directory contains the hardware emulation of the TLB, interrupts,
various devices, and so on.  Earth is a x86 paravirtual machine monitor.

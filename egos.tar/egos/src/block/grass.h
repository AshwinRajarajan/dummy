// content of grass.h NOT related to other parts of EGOS
#include <inttypes.h>
// content of grass.h related to other parts of EGOS
#ifndef CACHE_TEST
#include <earth/earth.h>
#include <egos/malloc.h>
#include <earth/log.h>
#include <egos/syscall.h>
#include <egos/block.h>
#endif // !CACHE_TEST

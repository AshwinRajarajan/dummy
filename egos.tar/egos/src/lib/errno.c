#include <sys/errno.h>

int errno = 0;

This directory contains the library routines available to user space
applications.

package com.airline.demo.models;

import com.airline.demo.utils.PositionAttributeConvertor;
import lombok.Data;

import javax.persistence.*;

@Data
@Entity
public class Arrival {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private long id;
    private long arrivalTime;
    private long flightId;
    private long originAirportId;
    private boolean connecting;
    private String gate;
    private String baggageClaimCounter;
    @Convert(converter = PositionAttributeConvertor.class)
    @Lob
    private Position arrivalPosition;

}

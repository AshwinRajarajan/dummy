package com.airline.demo.repo;

import com.airline.demo.models.Runner;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface RunnerRepository extends JpaRepository<Runner,Long> {
}

package com.airline.demo.models;

import com.airline.demo.utils.PositionAttributeConvertor;
import lombok.Data;

import javax.persistence.*;

@Data
@Entity
public class Departure {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private long id;
    private long flightId;
    private long departureTime;
    private long destinationAirportId;
    private boolean connecting;
    @Convert(converter = PositionAttributeConvertor.class)
    @Lob
    private Position departurePosition;
    private String gate;

}

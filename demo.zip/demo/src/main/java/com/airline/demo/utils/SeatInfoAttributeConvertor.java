package com.airline.demo.utils;

import com.airline.demo.models.Flight;
import com.airline.demo.models.Position;

import javax.persistence.AttributeConverter;
import javax.persistence.Converter;

@Converter
public class SeatInfoAttributeConvertor implements AttributeConverter<Flight.SeatInfo,String> {

    @Override
    public String convertToDatabaseColumn( Flight.SeatInfo attribute ) {
        return JsonUtil.toJson( attribute );
    }

    @Override
    public Flight.SeatInfo convertToEntityAttribute( String dbData ) {
        return JsonUtil.fromJson( dbData, Flight.SeatInfo.class );
    }
}


package com.airline.demo.repo;

import com.airline.demo.models.RunnerPosition;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface RunnerPositionRepository extends JpaRepository<RunnerPosition, Long> {

    List<RunnerPosition> findByGateAndTime( String gate, long time );

    List<RunnerPosition> findByRunnerIds(List<Long> runnerIds);
}

package com.airline.demo.models;

import com.airline.demo.utils.PositionAttributeConvertor;
import lombok.Data;

import javax.persistence.*;

@Data
@Entity
public class RunnerPosition {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private long id;
    private long runnerId;
    private long time;
    private String gate;
    @Convert(converter = PositionAttributeConvertor.class)
    @Lob
    private Position position;

}

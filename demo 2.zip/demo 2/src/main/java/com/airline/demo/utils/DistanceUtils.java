package com.airline.demo.utils;

import com.airline.demo.models.Departure;
import com.airline.demo.models.Position;
import com.airline.demo.models.RunnerPosition;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class DistanceUtils {

    public static double findDistanceBetween( Position position1, Position position2 ) {

        double longitude1 = Math.toRadians( position1.getLongitude() );
        double longitude2 = Math.toRadians( position2.getLongitude() );
        double latitude1 = Math.toRadians( position1.getLatitude() );
        double latitude2 = Math.toRadians( position2.getLatitude() );
        double dlon = longitude2 - longitude1;
        double dlat = latitude2 - latitude1;
        double a = Math.pow( Math.sin( dlat / 2 ), 2 )
                + Math.cos( latitude1 ) * Math.cos( latitude2 )
                * Math.pow( Math.sin( dlon / 2 ), 2 );
        double c = 2 * Math.asin( Math.sqrt( a ) );
        double r = 6371;
        return ( c * r );
    }

    public static Map<Long,List<Long>> findOptimalRouteForRunner( List<RunnerPosition> runners, List<Departure> flights ) {
        Map<Long,List<Long>> flightIdsByRunnerId = new HashMap<>();

        for ( RunnerPosition runnerPosition : runners ) {
            List<Departure> flightsForRunner = new ArrayList<>( flights );
            List<Long> flightIds = new ArrayList<>();

            while ( !flightsForRunner.isEmpty() ) {
                Departure nearestFlight = findNearestLocation( runnerPosition, flightsForRunner );
                flightIds.add( nearestFlight.getFlightId() );
                flightsForRunner.remove( nearestFlight );
            }
            flightIdsByRunnerId.put( runnerPosition.getRunnerId(), flightIds );
        }
        return flightIdsByRunnerId;
    }


    public static Departure findNearestLocation( RunnerPosition runnerPosition, List<Departure> flights ) {
        Departure nearestLocation = null;
        double minDistance = Double.MAX_VALUE;

        for ( Departure departure : flights ) {
            double distance = findDistanceBetween( runnerPosition.getPosition(), departure.getDeparturePosition() );
            if ( distance < minDistance ) {
                nearestLocation = departure;
                minDistance = distance;
            }
        }

        return nearestLocation;
    }

}

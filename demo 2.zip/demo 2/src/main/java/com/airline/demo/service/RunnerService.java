package com.airline.demo.service;

import com.airline.demo.dto.RunnerAvailabilityFetchDto;
import com.airline.demo.models.Departure;
import com.airline.demo.models.Flight;
import com.airline.demo.models.Runner;
import com.airline.demo.models.RunnerPosition;
import com.airline.demo.repo.*;
import com.airline.demo.utils.DistanceUtils;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class RunnerService {

    private final RunnerRepository runnerRepository;
    private final RunnerPositionRepository runnerPositionRepository;
    private final DepartureRepository departureRepository;
    private final FlightRepository flightRepository;
    private static final long BUFFER_TIME_IN_MILLIS = 30 * 60 * 1000;

    public List<Runner> findRunnerAvailability( RunnerAvailabilityFetchDto runnerAvailabilityFetchDto ) {
        List<RunnerPosition> runnerPositions = runnerPositionRepository.findByGateAndTime( runnerAvailabilityFetchDto.getGate(), runnerAvailabilityFetchDto.getTime() );
        List<Long> runnerIds = runnerPositions.stream().map( RunnerPosition::getRunnerId ).collect( Collectors.toList() );
        List<Runner> runners = runnerRepository.findAllById( runnerIds );
        return runners.stream().filter( Runner::isRunnerAvailable ).collect( Collectors.toList() );
    }

    public Map<String,List<String>> findOptimalRunnerRoute( long time ) {
        List<Departure> departures = departureRepository.findByDepartureTimeBetween( time, time + BUFFER_TIME_IN_MILLIS );
        List<Flight> flights = flightRepository.findAllById( departures.stream().map( Departure::getFlightId ).collect( Collectors.toList() ) );
        List<Runner> availableRunners = findAllActiveRunners();
        Map<Long,Runner> runnerById = availableRunners.stream().collect( Collectors.toMap( Runner::getId, Function.identity() ) );
        Map<Long,Flight> flightById = flights.stream().collect( Collectors.toMap( Flight::getId, Function.identity() ) );
        List<RunnerPosition> runnerPositions = runnerPositionRepository.findByRunnerIds( availableRunners.stream().map( Runner::getId ).collect( Collectors.toList() ) );
        Map<Long,List<Long>> optimalRouteForRunnerIds = DistanceUtils.findOptimalRouteForRunner( runnerPositions, departures );
        Map<String,List<String>> optimalRouteForRunners = new HashMap<>();
        optimalRouteForRunnerIds.forEach( ( key, value ) -> {
            Runner runner = runnerById.get( key );
            String runnerName = runner.getFirstName() + " " + runner.getLastName();
            List<String> flightCodes = value.stream().map( value1 -> flightById.get( value1 ).getFlightCode() ).collect( Collectors.toList() );
            optimalRouteForRunners.put( runnerName, flightCodes );
        } );
        return optimalRouteForRunners;
    }

    private List<Runner> findAllActiveRunners() {
        return runnerRepository.findAll().stream().filter( Runner::isRunnerAvailable ).collect( Collectors.toList() );
    }
}

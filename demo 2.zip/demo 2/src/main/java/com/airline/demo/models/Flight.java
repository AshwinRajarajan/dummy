package com.airline.demo.models;

import com.airline.demo.utils.SeatInfoAttributeConvertor;
import lombok.Data;

import javax.persistence.*;
import java.util.List;

@Data
@Entity
public class Flight {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private long id;
    private String name;
    private String flightCode;
    private String operator;
    private int maxAllowedBaggageInKgs;
    @Convert(converter = SeatInfoAttributeConvertor.class)
    private List<SeatInfo> seatInfos;

    @Data
    public static class SeatInfo {
        private int seatCount;
        private String seatClass;
    }

}

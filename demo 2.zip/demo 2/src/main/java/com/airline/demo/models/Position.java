package com.airline.demo.models;

import lombok.Data;

@Data
public class Position {

    private double latitude;
    private double longitude;

}

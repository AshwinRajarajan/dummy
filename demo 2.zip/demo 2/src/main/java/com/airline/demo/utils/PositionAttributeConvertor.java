package com.airline.demo.utils;

import com.airline.demo.models.Position;

import javax.persistence.AttributeConverter;
import javax.persistence.Converter;

@Converter
public class PositionAttributeConvertor implements AttributeConverter<Position,String> {

    @Override
    public String convertToDatabaseColumn( Position attribute ) {
        return JsonUtil.toJson( attribute );
    }

    @Override
    public Position convertToEntityAttribute( String dbData ) {
        return JsonUtil.fromJson( dbData, Position.class );
    }
}


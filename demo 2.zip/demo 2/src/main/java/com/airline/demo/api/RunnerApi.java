package com.airline.demo.api;

import com.airline.demo.dto.RunnerAvailabilityFetchDto;
import com.airline.demo.models.Runner;
import com.airline.demo.service.RunnerService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("runner")
@RequiredArgsConstructor
public class RunnerApi {

    private final RunnerService runnerService;

    @PostMapping("/find/availability")
    public List<Runner> findRunnerAvailability( @RequestBody RunnerAvailabilityFetchDto runnerAvailabilityFetchDto ) {
        return runnerService.findRunnerAvailability( runnerAvailabilityFetchDto );
    }

    @GetMapping("/find/route")
    public Map<String,List<String>> findRunnerRoute( @RequestParam long time ) {
        return runnerService.findOptimalRunnerRoute( time );
    }

}

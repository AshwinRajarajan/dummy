package com.airline.demo.api;

import com.airline.demo.models.Runner;
import com.airline.demo.models.RunnerPosition;
import com.airline.demo.repo.RunnerPositionRepository;
import com.airline.demo.repo.RunnerRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/runner/data")
@RequiredArgsConstructor
public class RunnerCrudApi {

    private final RunnerRepository runnerRepository;
    private final RunnerPositionRepository runnerPositionRepository;

    @PostMapping
    public Runner createRunner( @RequestBody Runner runner ) {
        return runnerRepository.save( runner );
    }

    @PostMapping
    public RunnerPosition createRunnerPosition(@RequestBody RunnerPosition runnerPosition ) {
        return runnerPositionRepository.save( runnerPosition );
    }

    @GetMapping("/{id}")
    public Runner getRunner( @PathVariable long id ) {
        return runnerRepository.findById( id ).orElse( null );
    }
}

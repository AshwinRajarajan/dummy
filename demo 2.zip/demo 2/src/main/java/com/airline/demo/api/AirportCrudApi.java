package com.airline.demo.api;

import com.airline.demo.models.Airport;
import com.airline.demo.repo.AirportRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/airport/data")
@RequiredArgsConstructor
public class AirportCrudApi {

    private final AirportRepository airportRepository;

    @PostMapping
    public Airport createAirport( @RequestBody Airport airport ) {
        return airportRepository.save( airport );
    }

    @GetMapping("/{id}")
    public Airport getAirport( @PathVariable long id ) {
        return airportRepository.findById( id ).orElse( null );
    }
}

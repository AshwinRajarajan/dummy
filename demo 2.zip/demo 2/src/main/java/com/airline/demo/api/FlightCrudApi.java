package com.airline.demo.api;

import com.airline.demo.models.Flight;
import com.airline.demo.repo.FlightRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/flight/data")
@RequiredArgsConstructor
public class FlightCrudApi {

    private final FlightRepository flightRepository;

    @PostMapping
    public Flight createFlight( @RequestBody Flight flight ) {
        return flightRepository.save( flight );
    }

    @GetMapping("/{id}")
    public Flight getFlight( @PathVariable long id ) {
        return flightRepository.findById( id ).orElse( null );
    }
}

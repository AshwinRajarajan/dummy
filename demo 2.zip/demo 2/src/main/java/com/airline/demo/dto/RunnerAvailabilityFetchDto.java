package com.airline.demo.dto;

import lombok.Data;

@Data
public class RunnerAvailabilityFetchDto {

    private long time;
    private int bufferTimeInSeconds;
    private String gate;

}
